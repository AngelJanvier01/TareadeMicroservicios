package com.example.cliente

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
